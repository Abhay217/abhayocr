from selenium import webdriver
from pynput.keyboard import Key, Controller
import pyautogui
import time
import os
import js2py

# img_folder_path = 'C://Users//Abhay//Documents//abhay//'
# dirListing = os.listdir(img_folder_path)

# j=len(dirListing)    
i = 21
# while i <= j:
browser = webdriver.Chrome(executable_path=r'C:\\Selenium\chromedriver.exe')
browser.maximize_window()
browser.get('https://www.google.com/search?q=schools+in+226003&oq=sc&aqs=chrome.0.69i59j69i57j69i59j0i433l2j0i131i433j46i131i433j69i60.2124j0j9&sourceid=chrome&ie=UTF-8')
time.sleep(1)
pyautogui.press("tab",i)
pyautogui.press("enter")
time.sleep(3)
pyautogui.press("tab",10)
pyautogui.press("enter")

    # time.sleep(1)
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # time.sleep(1)

    # pyautogui.press('enter')
    # time.sleep(1)

    # pyautogui.typewrite('C:\\Users\\Abhay\\Documents\\abhay')
    # time.sleep(1)

    # pyautogui.press('enter')
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")          
    # time.sleep(2)
    # pyautogui.press("right",i)
    # pyautogui.press("left")
    # pyautogui.press('enter')
    # time.sleep(2)
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press('enter')
    # time.sleep(5)
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press("tab")
    # pyautogui.press('enter')
    # time.sleep(2)
    # browser.quit()
    
    # i += 1
